
const loginPage = document.getElementById("loginPage");
const dashboardPage = document.getElementById("dashboardPage");

const roleDescriptions = {
    "Student": "Manage your room, meals and complaints.",
    "Warden": "Manage hostel rooms and student complaints.",
    "Mess Staff": "Manage daily hostel meal activities."
};

const roleServices = {
    "Student": [
        ["🛏️", "Room Details", "View room information.", "room"],
        ["🍽️", "Meal Booking", "Book your daily meals.", "meal"],
        ["📝", "Complaints", "Report hostel problems.", "complaint"]
    ],
    "Warden": [
        ["🛏️", "Room Allocation", "View room allocation demo.", "room"],
        ["📝", "Complaints", "Open complaint section demo.", "complaint"]
    ],
    "Mess Staff": [
        ["🍽️", "Meal Activities", "Open meal booking demo.", "meal"]
    ]
};

let requests = [];

document.getElementById("showPassword").addEventListener("change", function () {
    document.getElementById("password").type =
        this.checked ? "text" : "password";
});

document.getElementById("loginForm").addEventListener("submit", function (event) {
    event.preventDefault();

    const role = document.getElementById("role").value;
    const reg = document.getElementById("registration").value.trim();
    const password = document.getElementById("password").value;

    if (!role || !reg || !password) {
        showMessage("loginMessage", "Please fill in all fields.", "red");
        return;
    }

    // Frontend demo only; real authentication requires a backend.
    document.getElementById("welcomeRole").textContent = role;
    document.getElementById("welcomeReg").textContent = reg;
    document.getElementById("roleDescription").textContent =
        roleDescriptions[role];

    loginPage.classList.add("hidden");
    dashboardPage.classList.remove("hidden");

    ["roomSection", "mealSection", "complaintSection"].forEach(id => {
        document.getElementById(id).classList.add("hidden");
    });

    const grid = document.getElementById("servicesGrid");
    grid.replaceChildren();

    roleServices[role].forEach(service => {
        const article = document.createElement("article");
        article.className = "service";

        const emoji = document.createElement("div");
        emoji.className = "emoji";
        emoji.textContent = service[0];

        const heading = document.createElement("h3");
        heading.textContent = service[1];

        const description = document.createElement("p");
        description.textContent = service[2];

        const button = document.createElement("button");
        button.textContent = "Open";

        button.addEventListener("click", () => {
            const sectionIds = {
                room: "roomSection",
                meal: "mealSection",
                complaint: "complaintSection"
            };

            const section = document.getElementById(sectionIds[service[3]]);
            section.classList.remove("hidden");
            section.scrollIntoView({ behavior: "smooth" });
        });

        article.append(emoji, heading, description, button);
        grid.appendChild(article);
    });

    renderRequests();
});

function showMessage(id, text, color) {
    const element = document.getElementById(id);
    element.textContent = text;
    element.style.color = color;
}

function addRequest(type, description) {
    requests.unshift({
        type: type,
        description: description,
        status: "Demo only — not saved to database"
    });

    renderRequests();
}

function renderRequests() {
    const list = document.getElementById("requestsList");
    list.replaceChildren();

    if (requests.length === 0) {
        const empty = document.createElement("p");
        empty.className = "hint";
        empty.textContent = "No requests submitted yet.";
        list.appendChild(empty);
        return;
    }

    requests.forEach(request => {
        const item = document.createElement("div");
        item.className = "request";

        const title = document.createElement("strong");
        title.textContent = request.type;

        const details = document.createElement("p");
        details.textContent = request.description;

        const status = document.createElement("p");
        status.className = "hint";
        status.textContent = request.status;

        item.append(title, details, status);
        list.appendChild(item);
    });
}

document.getElementById("mealForm").addEventListener("submit", function (event) {
    event.preventDefault();

    const date = document.getElementById("mealDate").value;
    const meal = document.getElementById("mealType").value;

    if (!date || !meal) return;

    addRequest("Meal Booking", meal + " — " + date);
    showMessage("mealMessage", "Demo meal booking added!", "green");
    this.reset();
});

document.getElementById("complaintForm").addEventListener("submit", function (event) {
    event.preventDefault();

    const title = document.getElementById("complaintTitle").value.trim();
    const details = document.getElementById("complaintDetails").value.trim();

    if (!title || !details) return;

    addRequest("Complaint", title + ": " + details);
    showMessage("complaintMessage", "Demo complaint submitted!", "green");
    this.reset();
});

document.getElementById("logoutBtn").addEventListener("click", function () {
    dashboardPage.classList.add("hidden");
    loginPage.classList.remove("hidden");
    document.getElementById("loginForm").reset();
    showMessage("loginMessage", "", "");
});

document.getElementById("mealDate").min =
    new Date().toLocaleDateString("en-CA");
